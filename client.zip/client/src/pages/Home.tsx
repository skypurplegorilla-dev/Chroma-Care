import GameDashboard from '@/components/GameDashboard';
import { useAuth } from '@/hooks/useAuth';

export default function Home() {
  const { user } = useAuth();
  
  // Display name from user data (firstName + lastName or email)
  const username = user?.firstName 
    ? `${user.firstName}${user.lastName ? ' ' + user.lastName : ''}`
    : user?.email?.split('@')[0] || 'Player';
  
  return <GameDashboard username={username} />;
}
