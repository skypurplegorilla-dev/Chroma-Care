import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Heart, Sparkles, Clock, Shield } from 'lucide-react';

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="max-w-4xl w-full text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-primary via-purple-500 to-primary bg-clip-text text-transparent">
              Chroma
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground">
              Your mystical virtual companion awaits
            </p>
          </div>

          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Welcome Chroma into your life. Feed her daily, watch her thrive, and discover the consequences of neglect in this Tamagotchi-style experience.
          </p>

          <Button 
            size="lg" 
            className="text-lg px-8 py-6"
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-login"
          >
            Begin Your Journey
          </Button>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-16">
            <Card className="border-primary/20">
              <CardContent className="p-6 space-y-2">
                <Heart className="h-8 w-8 text-primary mx-auto" />
                <h3 className="font-semibold">Daily Care</h3>
                <p className="text-sm text-muted-foreground">
                  Feed Chroma once per day to keep her happy and healthy
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/20">
              <CardContent className="p-6 space-y-2">
                <Clock className="h-8 w-8 text-primary mx-auto" />
                <h3 className="font-semibold">Build Streaks</h3>
                <p className="text-sm text-muted-foreground">
                  Maintain daily feeding streaks and watch your bond grow
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/20">
              <CardContent className="p-6 space-y-2">
                <Sparkles className="h-8 w-8 text-primary mx-auto" />
                <h3 className="font-semibold">Emotional States</h3>
                <p className="text-sm text-muted-foreground">
                  Experience Chroma's changing moods through visual effects
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/20">
              <CardContent className="p-6 space-y-2">
                <Shield className="h-8 w-8 text-primary mx-auto" />
                <h3 className="font-semibold">Resurrection</h3>
                <p className="text-sm text-muted-foreground">
                  Discover the secret to bringing Chroma back if she fades away
                </p>
              </CardContent>
            </Card>
          </div>

          <p className="text-sm text-muted-foreground pt-8">
            Every interaction matters. Every day counts.
          </p>
        </div>
      </div>
    </div>
  );
}
