import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { isUnauthorizedError } from '@/lib/authUtils';
import PetDisplay, { PetState } from './PetDisplay';
import FeedButton from './FeedButton';
import StatusCard from './StatusCard';
import RevivalModal from './RevivalModal';
import EmotionalLogs from './EmotionalLogs';
import ThemeToggle from './ThemeToggle';
import { Flame, Clock, Heart, Calendar, LogOut } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { Pet, EmotionalLog } from '@shared/schema';
import { Button } from '@/components/ui/button';

interface GameDashboardProps {
  username?: string;
}

interface EmotionalLogAPI {
  id: string;
  petId: string;
  message: string;
  tone: string;
  createdAt: string;
}

interface PetData {
  pet: Pet;
  canFeed: boolean;
  logs: EmotionalLogAPI[];
}

export default function GameDashboard({ username = 'Player' }: GameDashboardProps) {
  const [showRevival, setShowRevival] = useState(false);
  const [revivalError, setRevivalError] = useState('');
  const { toast } = useToast();

  const { data: petData, isLoading } = useQuery<PetData>({
    queryKey: ['/api/pet'],
    refetchInterval: 60000, // Refetch every minute
  });

  const feedMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/pet/feed');
      return await res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/pet'] });
      toast({
        title: 'Chroma is fed!',
        description: data.message,
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: 'Cannot feed',
        description: error.message || 'Already fed today',
        variant: 'destructive',
      });
    },
  });

  const resurrectMutation = useMutation({
    mutationFn: async (secretPhrase: string) => {
      const res = await apiRequest('POST', '/api/pet/resurrect', { secretPhrase });
      return await res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/pet'] });
      setShowRevival(false);
      setRevivalError('');
      toast({
        title: 'Chroma returns!',
        description: data.message,
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      setRevivalError(error.message || 'Incorrect secret phrase');
    },
  });

  useEffect(() => {
    if (petData?.pet?.state === 'dead') {
      setShowRevival(true);
    }
  }, [petData?.pet?.state]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading Chroma...</p>
      </div>
    );
  }

  const pet = petData?.pet;
  const canFeed = petData?.canFeed;
  const logs = petData?.logs || [];
  const latestLog = logs[0];

  const getHealthStatus = () => {
    if (pet?.state === 'healthy') return 'Healthy';
    if (pet?.state === 'hungry') return 'Hungry';
    if (pet?.state === 'critical') return 'Critical';
    if (pet?.state === 'dead') return 'Dead';
    return 'Unknown';
  };

  const getNextCheckTime = () => {
    if (!pet?.lastFed) return 'Unknown';
    const lastFedTime = new Date(pet.lastFed);
    const nextCheck = new Date(lastFedTime.getTime() + 24 * 60 * 60 * 1000);
    if (nextCheck > new Date()) {
      return `In ${formatDistanceToNow(nextCheck)}`;
    }
    return 'Overdue';
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold text-foreground">Chroma</h1>
            <p className="text-sm text-muted-foreground">Welcome back, {username}!</p>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => window.location.href = '/api/logout'}
              data-testid="button-logout"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 md:py-12">
        <div className="space-y-12">
          <PetDisplay 
            state={pet?.state as PetState} 
            resurrectionCount={pet?.resurrectionCount}
            emotionalMessage={latestLog?.message}
          />

          <div className="flex justify-center">
            <FeedButton 
              onFeed={() => feedMutation.mutate()}
              isFed={!canFeed && pet?.state !== 'dead'}
              isDisabled={pet?.state === 'dead' || feedMutation.isPending}
              isCritical={pet?.state === 'critical'}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatusCard 
              icon={Flame} 
              label="Daily Streak" 
              value={`${pet?.streak || 0} days`}
              variant={(pet?.streak || 0) > 0 ? 'success' : 'default'}
            />
            <StatusCard 
              icon={Clock} 
              label="Last Fed" 
              value={pet?.lastFed ? formatDistanceToNow(new Date(pet.lastFed), { addSuffix: true }) : 'Never'}
              variant="default"
            />
            <StatusCard 
              icon={Heart} 
              label="Health Status" 
              value={getHealthStatus()}
              variant={pet?.state === 'healthy' ? 'success' : pet?.state === 'hungry' ? 'warning' : 'danger'}
            />
            <StatusCard 
              icon={Calendar} 
              label="Next Check" 
              value={getNextCheckTime()}
              variant="default"
            />
          </div>

          {logs.length > 0 && (
            <EmotionalLogs logs={logs} />
          )}
        </div>
      </main>

      <RevivalModal 
        isOpen={showRevival}
        onRevive={(phrase) => resurrectMutation.mutate(phrase)}
        onClose={() => {
          setShowRevival(false);
          setRevivalError('');
        }}
        error={revivalError}
      />
    </div>
  );
}
