import { Card, CardContent } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';

interface StatusCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  variant?: 'default' | 'success' | 'warning' | 'danger';
}

export default function StatusCard({ icon: Icon, label, value, variant = 'default' }: StatusCardProps) {
  const variantColors = {
    default: 'text-foreground',
    success: 'text-chart-3',
    warning: 'text-chart-2',
    danger: 'text-chart-5',
  };

  return (
    <Card data-testid={`card-status-${label.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className={`${variantColors[variant]}`}>
            <Icon className="w-8 h-8" />
          </div>
          <div className="flex-1">
            <p className="text-sm text-muted-foreground mb-1">{label}</p>
            <p className="text-2xl font-semibold" data-testid={`text-${label.toLowerCase().replace(/\s+/g, '-')}-value`}>
              {value}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
