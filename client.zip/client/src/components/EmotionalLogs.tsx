import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatDistanceToNow } from 'date-fns';

export interface EmotionalLogAPI {
  id: string;
  petId: string;
  message: string;
  tone: string;
  createdAt: string;
}

interface EmotionalLogsProps {
  logs: EmotionalLogAPI[];
}

export default function EmotionalLogs({ logs }: EmotionalLogsProps) {
  if (logs.length === 0) {
    return null;
  }

  const getToneColor = (tone: string) => {
    switch (tone) {
      case 'content':
        return 'text-chart-3';
      case 'healthy':
        return 'text-chart-3';
      case 'hungry':
        return 'text-chart-2';
      case 'critical':
        return 'text-chart-5';
      case 'dead':
        return 'text-muted-foreground';
      case 'resurrected':
        return 'text-primary';
      default:
        return 'text-foreground';
    }
  };

  return (
    <Card data-testid="card-emotional-logs">
      <CardHeader>
        <CardTitle className="text-xl font-display">Chroma's Journal</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-48">
          <div className="space-y-4">
            {logs.map((log) => (
              <div key={log.id} className="border-l-2 border-border pl-4 py-2" data-testid={`log-entry-${log.id}`}>
                <p className={`text-base font-medium ${getToneColor(log.tone)}`}>
                  {log.message}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}
                </p>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
