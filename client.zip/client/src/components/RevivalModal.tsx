import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface RevivalModalProps {
  isOpen: boolean;
  onRevive: (secretPhrase: string) => void;
  onClose: () => void;
  error?: string;
}

export default function RevivalModal({ isOpen, onRevive, onClose, error }: RevivalModalProps) {
  const [secretPhrase, setSecretPhrase] = useState('');

  const handleRevive = () => {
    if (!secretPhrase.trim()) {
      return;
    }
    onRevive(secretPhrase);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" data-testid="modal-revival">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display">Chroma has passed...</DialogTitle>
          <DialogDescription className="text-base pt-4">
            Speak the words to bring your companion back. But know this—she may return... different.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="secret-phrase">Secret Phrase</Label>
            <Input 
              id="secret-phrase"
              placeholder="Enter the secret phrase..."
              value={secretPhrase}
              onChange={(e) => setSecretPhrase(e.target.value)}
              data-testid="input-secret-phrase"
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  handleRevive();
                }
              }}
            />
            {error && (
              <p className="text-sm text-destructive" data-testid="text-error">
                {error}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              Hint: "Come back..."
            </p>
          </div>
          <Button 
            size="lg" 
            onClick={handleRevive}
            className="w-full"
            data-testid="button-revive"
            disabled={!secretPhrase.trim()}
          >
            Resurrect Chroma
          </Button>
          <p className="text-xs text-muted-foreground text-center">
            This will reset your daily streak. Her form may be altered.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
