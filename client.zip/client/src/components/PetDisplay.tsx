import { useEffect, useState } from 'react';
import happyCat from '@assets/stock_images/happy_cute_cat_sitti_33a3e3c1.jpg';
import hungryCat from '@assets/stock_images/sad_hungry_cat_with__04318354.jpg';
import sleepingCat from '@assets/stock_images/sleeping_cat_in_dim__c31c0b89.jpg';

export type PetState = 'healthy' | 'hungry' | 'critical' | 'dead' | 'resurrected';

interface PetDisplayProps {
  state: PetState;
  name?: string;
  resurrectionCount?: number;
  emotionalMessage?: string;
}

const petImages = {
  healthy: happyCat,
  hungry: hungryCat,
  critical: sleepingCat,
  dead: sleepingCat,
  resurrected: happyCat,
};

export default function PetDisplay({ state, name = "Chroma", resurrectionCount = 0, emotionalMessage }: PetDisplayProps) {
  const [isBreathing, setIsBreathing] = useState(true);

  useEffect(() => {
    if (state !== 'healthy' && state !== 'resurrected') {
      setIsBreathing(false);
    } else {
      setIsBreathing(true);
    }
  }, [state]);

  // Apply different visual effects based on state
  const getImageFilters = () => {
    if (state === 'hungry') {
      return 'grayscale(0.3) contrast(0.9)';
    }
    if (state === 'critical') {
      return 'grayscale(0.7) contrast(0.7) brightness(0.6)';
    }
    if (state === 'dead') {
      return 'grayscale(1) opacity(0.4)';
    }
    if (resurrectionCount > 0) {
      return 'hue-rotate(10deg) saturate(1.2)';
    }
    return 'none';
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="relative">
        <div className={`aspect-square rounded-3xl overflow-hidden shadow-2xl transition-all duration-500 ${
          isBreathing ? 'animate-[breathing_3s_ease-in-out_infinite]' : ''
        } ${state === 'critical' ? 'animate-pulse' : ''}`}>
          <img 
            src={petImages[state === 'resurrected' ? 'resurrected' : state]} 
            alt={`${name} - ${state}`}
            className="w-full h-full object-cover transition-all duration-700"
            style={{ 
              filter: getImageFilters()
            }}
          />
          {resurrectionCount > 0 && state !== 'dead' && (
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2">
                <div className="w-4 h-4 bg-primary/60 rounded-full blur-sm animate-pulse" />
              </div>
              <div className="absolute top-1/3 right-1/3">
                <div className="w-4 h-4 bg-primary/60 rounded-full blur-sm animate-pulse" style={{ animationDelay: '0.3s' }} />
              </div>
            </div>
          )}
          {state === 'dead' && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center">
              <div className="text-center text-white px-4">
                <p className="text-2xl font-display font-semibold mb-2">
                  {emotionalMessage || "She's gone..."}
                </p>
              </div>
            </div>
          )}
        </div>
        
        <div className="mt-6 text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">
            {name}
            {resurrectionCount > 0 && state !== 'dead' && (
              <span className="ml-2 text-primary text-sm align-super">✧</span>
            )}
          </h2>
          {emotionalMessage && (
            <p className={`text-lg font-medium transition-colors duration-500 ${
              state === 'healthy' ? 'text-chart-3' : 
              state === 'hungry' ? 'text-chart-2' :
              state === 'critical' ? 'text-chart-5' :
              state === 'resurrected' ? 'text-primary' :
              'text-muted-foreground'
            }`}>
              {emotionalMessage}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
