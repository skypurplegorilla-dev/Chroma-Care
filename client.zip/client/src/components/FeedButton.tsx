import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

interface FeedButtonProps {
  onFeed: () => void;
  isFed?: boolean;
  isDisabled?: boolean;
  isCritical?: boolean;
}

export default function FeedButton({ onFeed, isFed, isDisabled, isCritical }: FeedButtonProps) {
  if (isFed) {
    return (
      <Button 
        size="lg" 
        className="rounded-full px-12 py-6 text-lg"
        disabled
        data-testid="button-feed-disabled"
      >
        <Check className="w-5 h-5 mr-2" />
        Fed Today!
      </Button>
    );
  }

  return (
    <Button 
      size="lg" 
      variant="default"
      className={`rounded-full px-12 py-6 text-lg ${
        isCritical ? 'animate-pulse' : ''
      }`}
      onClick={onFeed}
      disabled={isDisabled}
      data-testid="button-feed"
    >
      🥣 Feed Chroma
    </Button>
  );
}
