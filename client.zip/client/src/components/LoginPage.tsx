import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import ThemeToggle from './ThemeToggle';
import happyCat from '@assets/stock_images/happy_cute_cat_sitti_33a3e3c1.jpg';

interface LoginPageProps {
  onLogin?: (username: string, password: string) => void;
  onSignup?: (username: string, password: string) => void;
}

export default function LoginPage({ onLogin, onSignup }: LoginPageProps) {
  const [isSignup, setIsSignup] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSignup && onSignup) {
      onSignup(username, password);
    } else if (!isSignup && onLogin) {
      onLogin(username, password);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <div className="absolute top-4 right-4 z-10">
        <ThemeToggle />
      </div>
      
      <div className="flex-1 bg-gradient-to-br from-primary/20 to-primary/10 dark:from-primary/10 dark:to-primary/5 p-8 flex items-center justify-center">
        <div className="max-w-md w-full text-center">
          <h1 className="text-5xl md:text-6xl font-display font-bold text-foreground mb-4">
            Meet Chroma
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Your daily companion who needs your love and care
          </p>
          <div className="rounded-3xl overflow-hidden shadow-2xl">
            <img src={happyCat} alt="Chroma the cat" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl font-display">
              {isSignup ? 'Create Account' : 'Welcome Back'}
            </CardTitle>
            <CardDescription>
              {isSignup 
                ? 'Start your journey with Chroma today' 
                : 'Continue caring for Chroma'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input 
                  id="username" 
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  data-testid="input-username"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input 
                  id="password" 
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  data-testid="input-password"
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full" 
                size="lg"
                data-testid="button-submit"
              >
                {isSignup ? 'Sign Up' : 'Log In'}
              </Button>
            </form>
            
            <div className="mt-6 text-center">
              <button
                type="button"
                onClick={() => setIsSignup(!isSignup)}
                className="text-sm text-primary hover-elevate active-elevate-2 px-2 py-1 rounded-md"
                data-testid="button-toggle-mode"
              >
                {isSignup 
                  ? 'Already have an account? Log in' 
                  : "Don't have an account? Sign up"}
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
