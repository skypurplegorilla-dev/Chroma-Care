import PetDisplay from '../PetDisplay';

export default function PetDisplayExample() {
  return <PetDisplay state="healthy" name="Chroma" />;
}
