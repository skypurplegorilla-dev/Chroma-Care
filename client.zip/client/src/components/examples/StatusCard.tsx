import StatusCard from '../StatusCard';
import { Flame, Clock, Heart, Calendar } from 'lucide-react';

export default function StatusCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-8 max-w-4xl">
      <StatusCard icon={Flame} label="Daily Streak" value="7 days" variant="success" />
      <StatusCard icon={Clock} label="Last Fed" value="2 hours ago" variant="default" />
      <StatusCard icon={Heart} label="Health Status" value="Healthy" variant="success" />
      <StatusCard icon={Calendar} label="Next Check" value="In 22 hours" variant="default" />
    </div>
  );
}
