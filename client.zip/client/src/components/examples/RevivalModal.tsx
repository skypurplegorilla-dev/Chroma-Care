import { useState } from 'react';
import RevivalModal from '../RevivalModal';
import { Button } from '@/components/ui/button';

export default function RevivalModalExample() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="p-8">
      <Button onClick={() => setIsOpen(true)}>Show Revival Modal</Button>
      <RevivalModal 
        isOpen={isOpen} 
        onRevive={() => {
          console.log('Reviving Chroma');
          setIsOpen(false);
        }}
        onClose={() => setIsOpen(false)}
      />
    </div>
  );
}
