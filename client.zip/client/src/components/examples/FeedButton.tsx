import { useState } from 'react';
import FeedButton from '../FeedButton';

export default function FeedButtonExample() {
  const [fed, setFed] = useState(false);

  return (
    <div className="flex items-center justify-center p-8">
      <FeedButton 
        onFeed={() => {
          setFed(true);
          console.log('Feed button clicked');
        }} 
        isFed={fed}
        isCritical={false}
      />
    </div>
  );
}
