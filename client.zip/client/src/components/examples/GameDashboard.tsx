import GameDashboard from '../GameDashboard';

export default function GameDashboardExample() {
  return <GameDashboard username="Alex" />;
}
