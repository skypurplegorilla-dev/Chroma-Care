import EmotionalLogs from '../EmotionalLogs';

export default function EmotionalLogsExample() {
  const mockLogs = [
    {
      id: '1',
      petId: 'mock-pet-id',
      message: "She blinked slowly. She's content.",
      tone: 'content',
      createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString() // 30 mins ago
    },
    {
      id: '2',
      petId: 'mock-pet-id',
      message: "She waited. The silence grew.",
      tone: 'hungry',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString() // 2 hours ago
    },
    {
      id: '3',
      petId: 'mock-pet-id',
      message: "She's grooming herself peacefully.",
      tone: 'healthy',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString() // 1 day ago
    }
  ];

  return (
    <div className="p-8 max-w-2xl">
      <EmotionalLogs logs={mockLogs} />
    </div>
  );
}
