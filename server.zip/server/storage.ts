import { type User, type UpsertUser, type Pet, type InsertPet, type EmotionalLog, type InsertEmotionalLog } from "@shared/schema";
import { db } from "./db";
import { users, pets, emotionalLogs } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User methods - Required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Pet methods
  getPetByUserId(userId: string): Promise<Pet | undefined>;
  createPet(pet: InsertPet): Promise<Pet>;
  updatePetState(petId: string, state: string): Promise<void>;
  feedPet(petId: string): Promise<void>;
  updatePetStreak(petId: string, streak: number): Promise<void>;
  updateResurrectionCount(petId: string): Promise<void>;
  
  // Emotional log methods
  createEmotionalLog(log: InsertEmotionalLog): Promise<EmotionalLog>;
  getRecentLogs(petId: string, limit?: number): Promise<EmotionalLog[]>;
}

export class DbStorage implements IStorage {
  // User methods - Required for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Pet methods
  async getPetByUserId(userId: string): Promise<Pet | undefined> {
    const result = await db.select().from(pets).where(eq(pets.userId, userId)).limit(1);
    return result[0];
  }

  async createPet(insertPet: InsertPet): Promise<Pet> {
    const result = await db.insert(pets).values(insertPet).returning();
    return result[0];
  }

  async updatePetState(petId: string, state: string): Promise<void> {
    await db.update(pets).set({ state }).where(eq(pets.id, petId));
  }

  async feedPet(petId: string): Promise<void> {
    await db.update(pets).set({ 
      lastFed: new Date(),
      state: 'healthy'
    }).where(eq(pets.id, petId));
  }

  async updatePetStreak(petId: string, streak: number): Promise<void> {
    await db.update(pets).set({ streak }).where(eq(pets.id, petId));
  }

  async updateResurrectionCount(petId: string): Promise<void> {
    const pet = await db.select().from(pets).where(eq(pets.id, petId)).limit(1);
    if (pet[0]) {
      await db.update(pets).set({ 
        resurrectionCount: pet[0].resurrectionCount + 1,
        state: 'healthy',
        lastFed: new Date(),
        streak: 0
      }).where(eq(pets.id, petId));
    }
  }

  // Emotional log methods
  async createEmotionalLog(log: InsertEmotionalLog): Promise<EmotionalLog> {
    const result = await db.insert(emotionalLogs).values(log).returning();
    return result[0];
  }

  async getRecentLogs(petId: string, limit: number = 5): Promise<EmotionalLog[]> {
    return await db.select()
      .from(emotionalLogs)
      .where(eq(emotionalLogs.petId, petId))
      .orderBy(desc(emotionalLogs.createdAt))
      .limit(limit);
  }
}

export const storage = new DbStorage();
