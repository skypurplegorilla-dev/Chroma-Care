import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPetSchema, insertEmotionalLogSchema } from "@shared/schema";
import { setupAuth, isAuthenticated } from "./replitAuth";

// Emotional messages based on pet state
const emotionalMessages = {
  healthy: {
    feed: [
      "She blinked slowly. She's content.",
      "A gentle purr resonates. She's happy.",
      "She stretches lazily. All is well.",
      "She nuzzles your hand. Pure bliss."
    ],
    present: [
      "She watches you with bright eyes.",
      "She's grooming herself peacefully.",
      "She's curled up, purring softly."
    ]
  },
  hungry: {
    present: [
      "She waited. The silence grew.",
      "Her eyes follow you, expectant.",
      "She meows softly. A gentle reminder.",
      "She sits by her bowl, patient but hungry."
    ]
  },
  critical: {
    present: [
      "She waited. The silence grew.",
      "The room feels quieter than usual.",
      "She's barely visible in the shadows.",
      "A faint presence, fading slowly."
    ]
  },
  dead: {
    present: [
      "Only echoes remain.",
      "The space feels empty now.",
      "She's gone. Only memories linger."
    ]
  }
};

// Calculate pet state based on time since last fed
function calculatePetState(lastFed: Date | null): string {
  if (!lastFed) return 'hungry';
  
  const now = new Date();
  const hoursSinceFed = (now.getTime() - new Date(lastFed).getTime()) / (1000 * 60 * 60);
  
  if (hoursSinceFed < 24) return 'healthy';
  if (hoursSinceFed < 48) return 'hungry';
  if (hoursSinceFed < 72) return 'critical';
  return 'dead';
}

// Check if feeding is allowed today (once per day)
function canFeedToday(lastFed: Date | null): boolean {
  if (!lastFed) return true;
  
  const now = new Date();
  const lastFedDate = new Date(lastFed);
  
  // Reset at midnight local time
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const lastFedDay = new Date(lastFedDate.getFullYear(), lastFedDate.getMonth(), lastFedDate.getDate());
  
  return today.getTime() > lastFedDay.getTime();
}

// Get random message from array
function getRandomMessage(messages: string[]): string {
  return messages[Math.floor(Math.random() * messages.length)];
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup Replit Auth
  await setupAuth(app);

  // Auth route - Get current user (allows unauthenticated access)
  app.get('/api/auth/user', async (req: any, res) => {
    try {
      // Return null if not authenticated
      if (!req.isAuthenticated() || !req.user?.claims?.sub) {
        return res.json(null);
      }
      
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Get current pet state
  app.get("/api/pet", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      
      let pet = await storage.getPetByUserId(userId);
      
      // Create pet if doesn't exist
      if (!pet) {
        pet = await storage.createPet({
          userId,
          name: "Chroma",
          state: "healthy",
          lastFed: new Date(),
          streak: 0,
          resurrectionCount: 0
        });
      }
      
      // Calculate current state based on time
      const currentState = calculatePetState(pet.lastFed);
      
      // Update state if changed
      if (currentState !== pet.state) {
        await storage.updatePetState(pet.id, currentState);
        pet.state = currentState;
        
        // Create emotional log for state change
        const messages = emotionalMessages[currentState as keyof typeof emotionalMessages];
        if (messages?.present) {
          await storage.createEmotionalLog({
            petId: pet.id,
            message: getRandomMessage(messages.present),
            tone: currentState
          });
        }
      }
      
      // Get recent logs
      const logs = await storage.getRecentLogs(pet.id, 3);
      
      // Check if can feed today
      const canFeed = canFeedToday(pet.lastFed);
      
      res.json({
        pet,
        canFeed,
        logs
      });
    } catch (error) {
      console.error('Error getting pet:', error);
      res.status(500).json({ error: 'Failed to get pet state' });
    }
  });

  // Feed the pet
  app.post("/api/pet/feed", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      
      const pet = await storage.getPetByUserId(userId);
      if (!pet) {
        return res.status(404).json({ error: 'Pet not found' });
      }
      
      // Check if already fed today
      if (!canFeedToday(pet.lastFed)) {
        return res.status(400).json({ error: 'Already fed today' });
      }
      
      // Check if pet is dead
      if (pet.state === 'dead') {
        return res.status(400).json({ error: 'Pet is dead, please resurrect first' });
      }
      
      // Update streak
      const newStreak = pet.streak + 1;
      await storage.updatePetStreak(pet.id, newStreak);
      
      // Feed the pet
      await storage.feedPet(pet.id);
      
      // Create emotional log
      const feedMessage = getRandomMessage(emotionalMessages.healthy.feed);
      await storage.createEmotionalLog({
        petId: pet.id,
        message: feedMessage,
        tone: 'content'
      });
      
      res.json({
        success: true,
        message: feedMessage,
        streak: newStreak
      });
    } catch (error) {
      console.error('Error feeding pet:', error);
      res.status(500).json({ error: 'Failed to feed pet' });
    }
  });

  // Resurrect the pet
  app.post("/api/pet/resurrect", isAuthenticated, async (req: any, res: Response) => {
    try {
      const { secretPhrase } = req.body;
      
      // Check secret phrase
      if (secretPhrase?.toLowerCase() !== "come back chroma") {
        return res.status(400).json({ error: 'Incorrect secret phrase' });
      }
      
      const userId = req.user.claims.sub;
      
      const pet = await storage.getPetByUserId(userId);
      if (!pet) {
        return res.status(404).json({ error: 'Pet not found' });
      }
      
      if (pet.state !== 'dead') {
        return res.status(400).json({ error: 'Pet is not dead' });
      }
      
      // Resurrect the pet
      await storage.updateResurrectionCount(pet.id);
      
      // Create emotional log
      await storage.createEmotionalLog({
        petId: pet.id,
        message: "She returns... different. Her eyes hold a faint glow.",
        tone: 'resurrected'
      });
      
      res.json({
        success: true,
        message: 'Chroma has returned!',
        resurrectionCount: pet.resurrectionCount + 1
      });
    } catch (error) {
      console.error('Error resurrecting pet:', error);
      res.status(500).json({ error: 'Failed to resurrect pet' });
    }
  });

  // Get emotional logs
  app.get("/api/pet/logs", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      
      const pet = await storage.getPetByUserId(userId);
      if (!pet) {
        return res.status(404).json({ error: 'Pet not found' });
      }
      
      const limit = parseInt(req.query.limit as string) || 10;
      const logs = await storage.getRecentLogs(pet.id, limit);
      
      res.json({ logs });
    } catch (error) {
      console.error('Error getting logs:', error);
      res.status(500).json({ error: 'Failed to get logs' });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
